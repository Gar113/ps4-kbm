# ps4-kbm — Keyboard & Mouse untuk game PS4 (plugin GoldHEN)

Cara kerja: plugin meng-hook `scePadRead`/`scePadReadState`, membaca keyboard/mouse USB,
lalu menggabungkannya ke data DualShock. Game mengira itu input pad biasa, jadi kompatibel
dengan hampir semua game. Pad asli tetap berfungsi bersamaan.

## Status
- [x] Pemetaan WASD->stik kiri, mouse->stik kanan (smoothing + deadzone boost), tombol, parser INI — dites (`make test`)
- [ ] `usb_input.c` (baca mouse/keyboard USB) — belum diisi, perlu diuji di konsol
- [ ] Panggilan hook (`Detour_*`) — sesuaikan dengan versi GoldHEN Plugins SDK-mu

## Build
    export OO_PS4_TOOLCHAIN=...   GOLDHEN_SDK=...
    make            # hasil: ps4-kbm.prx
    make test       # tes logika di PC

## Pasang
1. Salin `ps4-kbm.prx` ke `/data/GoldHEN/plugins/`
2. Salin `config/ps4-kbm.ini` ke `/data/GoldHEN/ps4-kbm.ini`
3. Tambahkan di `/data/GoldHEN/plugins.ini`:
       [default]
       /data/GoldHEN/plugins/ps4-kbm.prx
4. Colok keyboard + mouse USB, jalankan game.

## Catatan
Mouse analog tidak seakurat mouse sungguhan karena game tetap membaca "stik". Naikkan
`deadzone_boost` jika kamera tersendat di gerakan kecil; turunkan `sensitivity` jika terlalu liar.
