#include "kbm_map.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

static void add_bind(kbm_cfg *c, uint8_t key, uint32_t btn) {
    if (c->n_binds < 32) { c->binds[c->n_binds].key = key; c->binds[c->n_binds].btn = btn; c->n_binds++; }
}

void kbm_cfg_default(kbm_cfg *c) {
    memset(c, 0, sizeof *c);
    c->k_up = 0x1A; c->k_left = 0x04; c->k_down = 0x16; c->k_right = 0x07; /* W A S D */
    c->sensitivity = 6.0f; c->deadzone_boost = 0.18f; c->smoothing = 0.35f;
    c->mouse_l_btn = PAD_R2; c->mouse_r_btn = PAD_L2; c->mouse_m_btn = PAD_R3;
    add_bind(c, 0x2C, PAD_CROSS);    /* Space  */
    add_bind(c, 0xE0, PAD_CIRCLE);   /* LCtrl  */
    add_bind(c, 0x15, PAD_SQUARE);   /* R      */
    add_bind(c, 0x08, PAD_TRIANGLE); /* E      */
    add_bind(c, 0x14, PAD_L1);       /* Q      */
    add_bind(c, 0x09, PAD_R1);       /* F      */
    add_bind(c, 0xE1, PAD_L3);       /* LShift */
    add_bind(c, 0x19, PAD_R3);       /* V      */
    add_bind(c, 0x29, PAD_OPTIONS);  /* Esc    */
    add_bind(c, 0x2B, PAD_TOUCHPAD); /* Tab    */
    add_bind(c, 0x1E, PAD_UP);       /* 1      */
    add_bind(c, 0x1F, PAD_RIGHT);    /* 2      */
    add_bind(c, 0x20, PAD_DOWN);     /* 3      */
    add_bind(c, 0x21, PAD_LEFT);     /* 4      */
}

static uint32_t btn_by_name(const char *n) {
    static const struct { const char *s; uint32_t v; } t[] = {
        {"cross",PAD_CROSS},{"circle",PAD_CIRCLE},{"square",PAD_SQUARE},{"triangle",PAD_TRIANGLE},
        {"l1",PAD_L1},{"r1",PAD_R1},{"l2",PAD_L2},{"r2",PAD_R2},{"l3",PAD_L3},{"r3",PAD_R3},
        {"options",PAD_OPTIONS},{"touchpad",PAD_TOUCHPAD},
        {"up",PAD_UP},{"down",PAD_DOWN},{"left",PAD_LEFT},{"right",PAD_RIGHT},{0,0}};
    for (int i = 0; t[i].s; i++) if (!strcmp(t[i].s, n)) return t[i].v;
    return 0;
}

static int key_by_name(const char *n) {
    if (strlen(n) == 1) {
        char ch = (char)tolower((unsigned char)n[0]);
        if (ch >= 'a' && ch <= 'z') return 0x04 + (ch - 'a');
        if (ch >= '1' && ch <= '9') return 0x1E + (ch - '1');
        if (ch == '0') return 0x27;
    }
    if (!strcmp(n,"space")) return 0x2C;
    if (!strcmp(n,"esc")) return 0x29;
    if (!strcmp(n,"tab")) return 0x2B;
    if (!strcmp(n,"enter")) return 0x28;
    if (!strcmp(n,"lctrl")) return 0xE0;
    if (!strcmp(n,"lshift")) return 0xE1;
    if (!strcmp(n,"lalt")) return 0xE2;
    return -1;
}

/* Format baris:  key.<nama>=<tombol_pad>  |  sensitivity=6.0 | smoothing=0.35 | deadzone_boost=0.18
                  mouse.left=r2 | mouse.right=l2 | mouse.middle=r3 */
int kbm_cfg_load(kbm_cfg *c, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    char line[128]; int custom_binds = 0;
    while (fgets(line, sizeof line, f)) {
        char *p = line; while (isspace((unsigned char)*p)) p++;
        if (*p == '#' || *p == ';' || !*p) continue;
        char *eq = strchr(p, '='); if (!eq) continue;
        *eq = 0; char *k = p, *v = eq + 1;
        for (char *e = k + strlen(k); e > k && isspace((unsigned char)e[-1]); ) *--e = 0;
        while (isspace((unsigned char)*v)) v++;
        for (char *e = v + strlen(v); e > v && isspace((unsigned char)e[-1]); ) *--e = 0;
        for (char *q = k; *q; q++) *q = (char)tolower((unsigned char)*q);
        for (char *q = v; *q; q++) *q = (char)tolower((unsigned char)*q);
        if (!strcmp(k,"sensitivity")) c->sensitivity = (float)atof(v);
        else if (!strcmp(k,"smoothing")) c->smoothing = (float)atof(v);
        else if (!strcmp(k,"deadzone_boost")) c->deadzone_boost = (float)atof(v);
        else if (!strcmp(k,"mouse.left")) c->mouse_l_btn = btn_by_name(v);
        else if (!strcmp(k,"mouse.right")) c->mouse_r_btn = btn_by_name(v);
        else if (!strcmp(k,"mouse.middle")) c->mouse_m_btn = btn_by_name(v);
        else if (!strncmp(k,"key.",4)) {
            int kc = key_by_name(k + 4); uint32_t b = btn_by_name(v);
            if (kc < 0 || !b) continue;
            if (!custom_binds) { c->n_binds = 0; custom_binds = 1; }
            add_bind(c, (uint8_t)kc, b);
        }
    }
    fclose(f);
    return 0;
}

static uint8_t to_axis(float v) { /* -1..1 -> 0..255 */
    if (v > 1.f) v = 1.f;
    if (v < -1.f) v = -1.f;
    return (uint8_t)lrintf(128.f + v * 127.f);
}

void kbm_apply(const kbm_cfg *c, const kbm_state *s, pad_out *o, float sm[2]) {
    /* Stik kiri dari WASD (diagonal dinormalisasi) */
    float lx = (float)(s->keys[c->k_right] - s->keys[c->k_left]);
    float ly = (float)(s->keys[c->k_down]  - s->keys[c->k_up]);
    float m = sqrtf(lx*lx + ly*ly); if (m > 1.f) { lx /= m; ly /= m; }
    o->lx = to_axis(lx); o->ly = to_axis(ly);

    /* Mouse -> stik kanan (dihaluskan, plus dorongan melewati deadzone) */
    float tx = (float)s->mouse_dx * c->sensitivity / 127.f;
    float ty = (float)s->mouse_dy * c->sensitivity / 127.f;
    sm[0] = sm[0] * c->smoothing + tx * (1.f - c->smoothing);
    sm[1] = sm[1] * c->smoothing + ty * (1.f - c->smoothing);
    float rx = sm[0], ry = sm[1];
    float rm = sqrtf(rx*rx + ry*ry);
    if (rm > 0.001f) {
        float boost = c->deadzone_boost;
        float nm = boost + rm * (1.f - boost); if (nm > 1.f) nm = 1.f;
        rx *= nm / rm; ry *= nm / rm;
    } else { rx = ry = 0; }
    o->rx = to_axis(rx); o->ry = to_axis(ry);

    /* Tombol */
    uint32_t b = 0;
    for (int i = 0; i < c->n_binds; i++) if (s->keys[c->binds[i].key]) b |= c->binds[i].btn;
    if (s->mouse_buttons & KBM_MOUSE_L) b |= c->mouse_l_btn;
    if (s->mouse_buttons & KBM_MOUSE_R) b |= c->mouse_r_btn;
    if (s->mouse_buttons & KBM_MOUSE_M) b |= c->mouse_m_btn;
    o->buttons = b;
    o->l2 = (b & PAD_L2) ? 255 : 0;
    o->r2 = (b & PAD_R2) ? 255 : 0;
}
