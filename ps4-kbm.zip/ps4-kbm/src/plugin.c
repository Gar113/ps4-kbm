/*
 * ps4-kbm — plugin GoldHEN: keyboard + mouse -> DualShock virtual.
 *
 * STATUS: kerangka. Logika pemetaan (kbm_map.c) sudah dites. Bagian yang
 * BELUM terverifikasi di konsol ditandai [UNVERIFIED]: nama/signature API
 * input USB dan API hook di SDK versimu. Cek header SDK yang kamu pakai.
 */
#include <stdint.h>
#include <string.h>
#include "kbm_map.h"

/* ---- Plugin SDK GoldHEN (illusion0001/GoldHEN_Plugins_SDK) ---- */
#include <Common.h>
#include <plugin_common.h>
/* [UNVERIFIED] API detour: sesuaikan dengan header SDK-mu (Detour / HOOK_*). */
#include <Detour.h>

#define CFG_PATH "/data/GoldHEN/ps4-kbm.ini"
#define PAD_HANDLE_ANY (-1)

/* Awalan struct ScePadData yang kita ubah (layout lengkap lebih panjang). */
typedef struct {
    uint32_t buttons;
    struct { uint8_t x, y; } leftStick, rightStick;
    struct { uint8_t l2, r2; } analogButtons;
    /* ... sisa field dibiarkan apa adanya ... */
} PadDataHead;

/* ---- Sumber input USB [UNVERIFIED] ----
 * Mouse : libSceMouse  (sceMouseInit / sceMouseOpen / sceMouseRead)
 * Keyboard: libSceIme keyboard / HID langsung via libSceUsbd.
 * Implementasikan dua fungsi ini; sisanya sudah siap.
 */
extern int  usb_input_init(void);
extern void usb_input_poll(kbm_state *out);   /* isi keys[], mouse_buttons, mouse_dx/dy */

static kbm_cfg   g_cfg;
static kbm_state g_state;
static float     g_smooth[2];
static Detour    g_hook_read, g_hook_readstate;

typedef int (*scePadReadState_t)(int handle, void *data);
typedef int (*scePadRead_t)(int handle, void *data, int count);

static void inject(PadDataHead *d) {
    pad_out o;
    usb_input_poll(&g_state);
    kbm_apply(&g_cfg, &g_state, &o, g_smooth);
    g_state.mouse_dx = g_state.mouse_dy = 0;

    /* Gabungkan: input KBM menimpa hanya bila ada aktivitas, agar pad asli tetap bisa dipakai */
    d->buttons |= o.buttons;
    if (o.lx != 128 || o.ly != 128) { d->leftStick.x  = o.lx; d->leftStick.y  = o.ly; }
    if (o.rx != 128 || o.ry != 128) { d->rightStick.x = o.rx; d->rightStick.y = o.ry; }
    if (o.l2) d->analogButtons.l2 = o.l2;
    if (o.r2) d->analogButtons.r2 = o.r2;
}

static int hk_scePadReadState(int handle, void *data) {
    int ret = ((scePadReadState_t)g_hook_readstate.original)(handle, data);
    if (ret == 0 && data) inject((PadDataHead *)data);
    return ret;
}

/* scePadRead mengembalikan banyak frame; ubah frame terbaru (indeks 0). */
static int hk_scePadRead(int handle, void *data, int count) {
    int ret = ((scePadRead_t)g_hook_read.original)(handle, data, count);
    if (ret > 0 && data) inject((PadDataHead *)data);
    return ret;
}

/* Titik masuk plugin GoldHEN */
int32_t attr_module_hidden module_start(size_t argc, const void *args) {
    kbm_cfg_default(&g_cfg);
    kbm_cfg_load(&g_cfg, CFG_PATH);     /* abaikan jika file tidak ada */
    usb_input_init();

    /* [UNVERIFIED] ganti dengan pemanggilan Detour dari SDK-mu */
    Detour_Create(&g_hook_readstate, "libScePad.sprx", "scePadReadState", hk_scePadReadState);
    Detour_Create(&g_hook_read,      "libScePad.sprx", "scePadRead",      hk_scePadRead);
    return 0;
}

int32_t attr_module_hidden module_stop(size_t argc, const void *args) {
    Detour_Remove(&g_hook_readstate);
    Detour_Remove(&g_hook_read);
    return 0;
}
