/*
 * ps4-kbm — plugin GoldHEN: keyboard + mouse -> DualShock virtual.
 * Memakai makro hook asli dari GoldHEN Plugins SDK (Utilities.h / Detour.h).
 * Bagian input USB ada di usb_input.c (masih perlu diselesaikan).
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "kbm_map.h"

#include <Common.h>
#include <GoldHEN.h>
#include <Utilities.h>
#include <Detour.h>

#ifndef attr_public
#define attr_public __attribute__((visibility("default")))
#endif

#define CFG_PATH "/data/GoldHEN/ps4-kbm.ini"

/* Fungsi libScePad yang di-hook (di-link lewat stub -lScePad) */
extern int scePadReadState(int handle, void *data);
extern int scePadRead(int handle, void *data, int count);

typedef int (*scePadReadState_t)(int handle, void *data);
typedef int (*scePadRead_t)(int handle, void *data, int count);

/* Awalan struct ScePadData yang kita ubah (layout lengkap lebih panjang). */
typedef struct {
    uint32_t buttons;
    struct { uint8_t x, y; } leftStick, rightStick;
    struct { uint8_t l2, r2; } analogButtons;
} PadDataHead;

extern int  usb_input_init(void);
extern void usb_input_poll(kbm_state *out);

static kbm_cfg   g_cfg;
static kbm_state g_state;
static float     g_smooth[2];

HOOK_INIT(scePadReadState);
HOOK_INIT(scePadRead);

static void inject(PadDataHead *d) {
    pad_out o;
    usb_input_poll(&g_state);
    kbm_apply(&g_cfg, &g_state, &o, g_smooth);
    g_state.mouse_dx = g_state.mouse_dy = 0;

    /* Pad asli tetap berfungsi: KBM hanya menimpa saat ada aktivitas */
    d->buttons |= o.buttons;
    if (o.lx != 128 || o.ly != 128) { d->leftStick.x  = o.lx; d->leftStick.y  = o.ly; }
    if (o.rx != 128 || o.ry != 128) { d->rightStick.x = o.rx; d->rightStick.y = o.ry; }
    if (o.l2) d->analogButtons.l2 = o.l2;
    if (o.r2) d->analogButtons.r2 = o.r2;
}

/* Nama fungsi hook harus <nama>_hook (aturan makro HOOK) */
static int scePadReadState_hook(int handle, void *data) {
    int ret = HOOK_CONTINUE(scePadReadState, scePadReadState_t, handle, data);
    if (ret == 0 && data) inject((PadDataHead *)data);
    return ret;
}

static int scePadRead_hook(int handle, void *data, int count) {
    int ret = HOOK_CONTINUE(scePadRead, scePadRead_t, handle, data, count);
    if (ret > 0 && data) inject((PadDataHead *)data);   /* frame 0 = terbaru */
    return ret;
}

int32_t attr_public plugin_load(int32_t argc, const char *argv[]) {
    (void)argc; (void)argv;
    klog("[ps4-kbm] plugin_load\n");
    kbm_cfg_default(&g_cfg);
    kbm_cfg_load(&g_cfg, CFG_PATH);
    usb_input_init();
    HOOK(scePadReadState);
    HOOK(scePadRead);
    return 0;
}

int32_t attr_public plugin_unload(int32_t argc, const char *argv[]) {
    (void)argc; (void)argv;
    UNHOOK(scePadReadState);
    UNHOOK(scePadRead);
    return 0;
}
