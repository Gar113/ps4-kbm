#ifndef HID_KBD_H
#define HID_KBD_H
#include <stdint.h>
#include "kbm_map.h"
/* Terapkan laporan keyboard USB HID boot protocol (8 byte) ke s->keys[]. */
void hid_kbd_apply(kbm_state *s, const uint8_t rep[8]);
#endif
