#ifndef KBM_MAP_H
#define KBM_MAP_H
#include <stdint.h>

/* Bitmask tombol pad PS4 (ORBIS_PAD_BUTTON_*) */
#define PAD_L3        0x00000002u
#define PAD_R3        0x00000004u
#define PAD_OPTIONS   0x00000008u
#define PAD_UP        0x00000010u
#define PAD_RIGHT     0x00000020u
#define PAD_DOWN      0x00000040u
#define PAD_LEFT      0x00000080u
#define PAD_L2        0x00000100u
#define PAD_R2        0x00000200u
#define PAD_L1        0x00000400u
#define PAD_R1        0x00000800u
#define PAD_TRIANGLE  0x00001000u
#define PAD_CIRCLE    0x00002000u
#define PAD_CROSS     0x00004000u
#define PAD_SQUARE    0x00008000u
#define PAD_TOUCHPAD  0x00100000u

/* Kode tombol keyboard = USB HID usage ID (A=0x04 ... Z=0x1D, 1=0x1E, Space=0x2C) */
#define KBM_MAX_KEYS 256
#define KBM_MOUSE_L 0x01
#define KBM_MOUSE_R 0x02
#define KBM_MOUSE_M 0x04

typedef struct {
    uint8_t  keys[KBM_MAX_KEYS]; /* 1 = ditekan */
    uint8_t  mouse_buttons;      /* KBM_MOUSE_* */
    int32_t  mouse_dx, mouse_dy; /* delta sejak poll terakhir */
} kbm_state;

typedef struct {
    uint32_t buttons;
    uint8_t  lx, ly, rx, ry;     /* 0..255, tengah = 128 */
    uint8_t  l2, r2;             /* 0..255 */
} pad_out;

typedef struct {
    uint8_t k_up, k_down, k_left, k_right;      /* stik kiri (WASD) */
    float   sensitivity;                         /* mouse -> stik kanan */
    float   deadzone_boost;                      /* dorongan melewati deadzone game (0..1) */
    float   smoothing;                           /* 0 = tanpa, 0.9 = sangat halus */
    uint8_t map_key[KBM_MAX_KEYS / 8];           /* tidak dipakai, cadangan */
    struct { uint8_t key; uint32_t btn; } binds[32];
    int     n_binds;
    uint32_t mouse_l_btn, mouse_r_btn, mouse_m_btn;
} kbm_cfg;

void kbm_cfg_default(kbm_cfg *c);
int  kbm_cfg_load(kbm_cfg *c, const char *path);   /* 0 = ok */
/* Gabungkan state KBM ke pad_out. `smooth` menyimpan keadaan antar frame. */
void kbm_apply(const kbm_cfg *c, const kbm_state *s, pad_out *out, float smooth[2]);
#endif
