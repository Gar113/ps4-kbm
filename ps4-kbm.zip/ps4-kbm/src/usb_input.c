/*
 * Sumber input USB.
 * Mouse   : libSceMouse  [UNVERIFIED: signature dari ingatan, cek header SDK-mu]
 * Keyboard: parser HID sudah dites; pengambilan laporan dari perangkat
 *           (kbd_fetch_report) BELUM diisi — itu bagian tersulit.
 */
#include "kbm_map.h"
#include "hid_kbd.h"
#include <string.h>

typedef struct {
    uint64_t timestamp; uint8_t connected; uint8_t pad0[3];
    uint32_t buttons; int32_t xAxis, yAxis, wheel, tilt; uint8_t reserve[8];
} MouseData;

extern int sceMouseInit(void);
extern int sceMouseOpen(int userId, int type, int index, void *param);
extern int sceMouseRead(int handle, MouseData *data, int num);

static int g_mouse = -1;

/* TODO: ambil 8 byte laporan keyboard USB. Return 1 jika ada laporan baru, 0 jika tidak. */
static int kbd_fetch_report(uint8_t out[8]) { (void)out; return 0; }

int usb_input_init(void) {
    sceMouseInit();
    g_mouse = sceMouseOpen(0xFF /* user aktif: sesuaikan */, 0, 0, NULL);
    return 0;
}

void usb_input_poll(kbm_state *out) {
    MouseData md[8];
    if (g_mouse >= 0) {
        int n = sceMouseRead(g_mouse, md, 8);
        for (int i = 0; i < n; i++) {
            out->mouse_dx += md[i].xAxis;
            out->mouse_dy += md[i].yAxis;
            out->mouse_buttons = (uint8_t)(md[i].buttons & 7);
        }
    }
    uint8_t rep[8];
    if (kbd_fetch_report(rep)) hid_kbd_apply(out, rep);
}
