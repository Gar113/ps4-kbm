#include "hid_kbd.h"
#include <string.h>
void hid_kbd_apply(kbm_state *s, const uint8_t rep[8]) {
    memset(s->keys, 0, 0xE8);
    for (int i = 0; i < 8; i++)            /* byte 0: modifier -> 0xE0..0xE7 */
        if (rep[0] & (1u << i)) s->keys[0xE0 + i] = 1;
    for (int i = 2; i < 8; i++)            /* byte 2..7: usage ID aktif; 1 = error rollover */
        if (rep[i] >= 4 && rep[i] < 0xE0) s->keys[rep[i]] = 1;
}
