#include "../src/kbm_map.h"
#include "../src/hid_kbd.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>
int main(void) {
    kbm_cfg c; kbm_cfg_default(&c);
    kbm_state s; memset(&s, 0, sizeof s);
    pad_out o; float sm[2] = {0,0};

    kbm_apply(&c, &s, &o, sm);
    assert(o.lx == 128 && o.ly == 128 && o.rx == 128 && o.ry == 128 && o.buttons == 0);

    s.keys[0x1A] = 1;                      /* W -> stik kiri ke atas (y kecil) */
    kbm_apply(&c, &s, &o, sm);
    assert(o.ly == 1 && o.lx == 128);

    s.keys[0x07] = 1;                      /* + D -> diagonal, dinormalisasi */
    kbm_apply(&c, &s, &o, sm);
    assert(o.lx > 200 && o.lx < 230 && o.ly > 20 && o.ly < 50);

    s.keys[0x2C] = 1; s.mouse_buttons = KBM_MOUSE_L | KBM_MOUSE_R;
    kbm_apply(&c, &s, &o, sm);
    assert((o.buttons & PAD_CROSS) && (o.buttons & PAD_R2) && (o.buttons & PAD_L2));
    assert(o.r2 == 255 && o.l2 == 255);

    memset(&s, 0, sizeof s); s.mouse_dx = 20;   /* gerak mouse ke kanan */
    sm[0] = sm[1] = 0;
    kbm_apply(&c, &s, &o, sm);
    assert(o.rx > 128 && o.ry == 128);

    FILE *f = fopen("/tmp/t.ini", "w");
    fputs("sensitivity=3.5\nkey.x=cross\nkey.lshift=l3\nmouse.left=r1\n", f); fclose(f);
    kbm_cfg c2; kbm_cfg_default(&c2);
    assert(kbm_cfg_load(&c2, "/tmp/t.ini") == 0);
    assert(c2.n_binds == 2 && c2.sensitivity == 3.5f && c2.mouse_l_btn == PAD_R1);
    uint8_t rep[8] = {0x02, 0, 0x1A, 0x07, 0, 0, 0, 0}; /* LShift + W + D */
    memset(&s, 0, sizeof s); hid_kbd_apply(&s, rep);
    assert(s.keys[0xE1] && s.keys[0x1A] && s.keys[0x07] && !s.keys[0x04]);
    uint8_t none[8] = {0}; hid_kbd_apply(&s, none);
    assert(!s.keys[0x1A] && !s.keys[0xE1]);
    puts("semua tes lulus");
    return 0;
}
